const fetchUserData = async () => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const userData = {
                name: 'John Doe',
                email: 'johndoe@yahoo.com',
                avatar: 'assets/images/avatar.png',
                gender: 'M',
                login: 'johndoe123',
                password: '011648',
                address: 'Tangier, Morocco'
            };
            resolve(userData);
        }, 3500);
    });
};

const fetchUserOrders = async (userId) => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const orders = [
                { orderId: 1, product: 'Pc Portable', amount: '$1200' },
                { orderId: 2, product: 'Kaspersky', amount: '$90' },
                { orderId: 3, product: 'Volvo', amount: '$16000' }
            ];
            resolve(orders);
        }, 2000);
    });
};

const displayUserProfile = (userData) => {
    const profileDiv = document.getElementById('profile');
    profileDiv.innerHTML = `
        <img src="${userData.avatar}" alt="Avatar">
        <h2>${userData.name}</h2>
        <table>
            <tr><td>Email:</td><td>${userData.email}</td></tr>
            <tr><td>Gender:</td><td>${userData.gender}</td></tr>
            <tr><td>Login:</td><td>${userData.login}</td></tr>
            <tr><td>Password:</td><td>${userData.password}</td></tr>
            <tr><td>Address:</td><td>${userData.address}</td></tr>
        </table>
    `;
};

const displayUserOrders = (orders) => {
    const ordersDiv = document.createElement('div');
    ordersDiv.innerHTML = '<h3>User Orders</h3>';
    const ordersTable = document.createElement('table');

    orders.forEach(order => {
        const row = ordersTable.insertRow();
        const cell1 = row.insertCell(0);
        const cell2 = row.insertCell(1);
        const cell3 = row.insertCell(2);
        cell1.innerHTML = order.orderId;
        cell2.innerHTML = order.product;
        cell3.innerHTML = order.amount;
    });

    ordersDiv.appendChild(ordersTable);
    document.body.appendChild(ordersDiv);
};
