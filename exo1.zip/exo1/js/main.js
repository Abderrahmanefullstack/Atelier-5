const main = async () => {
    try {
        const userData = await fetchUserData();
        console.log('User Data:', userData);
        displayUserProfile(userData);

        const userOrders = await fetchUserOrders(userData.login);
        console.log('User Orders:', userOrders);
        displayUserOrders(userOrders);
    } catch (error) {
        console.error('Error:', error);
    }
};

main();
