const apiUrl = 'http://127.0.0.1:8000';

const fetchRooms = async () => {
    try {
        const response = await fetch(`${apiUrl}/rooms`);
        if (!response.ok) {
            throw new Error('Failed to fetch rooms');
        }
        return await response.json();
    } catch (error) {
        console.error(error);
        throw error;
    }
};

const createRoom = async (room) => {
    try {
        const response = await fetch(`${apiUrl}/rooms`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(room),
        });
        if (!response.ok) {
            throw new Error('Failed to create room');
        }
        return await response.json();
    } catch (error) {
        console.error(error);
        throw error;
    }
};

const updateRoom = async (id, room) => {
    try {
        const response = await fetch(`${apiUrl}/rooms/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(room),
        });
        if (!response.ok) {
            throw new Error('Failed to update room');
        }
        return await response.json();
    } catch (error) {
        console.error(error);
        throw error;
    }
};

const deleteRoom = async (id) => {
    try {
        const response = await fetch(`${apiUrl}/rooms/${id}`, {
            method: 'DELETE',
        });
        if (!response.ok) {
            throw new Error('Failed to delete room');
        }
    } catch (error) {
        console.error(error);
        throw error;
    }
};
