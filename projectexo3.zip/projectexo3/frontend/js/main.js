document.addEventListener('DOMContentLoaded', () => {
    const createRoomForm = document.getElementById('createRoomForm');
    const roomList = document.getElementById('roomList');

    const loadRooms = async () => {
        try {
            const rooms = await fetchRooms();
            roomList.innerHTML = '';
            rooms.forEach(room => {
                const listItem = document.createElement('li');
                listItem.textContent = `${room.name} (Capacity: ${room.capacity})`;
                roomList.appendChild(listItem);

                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Delete';
                deleteButton.addEventListener('click', async () => {
                    await deleteRoom(room.id);
                    loadRooms();
                });
                listItem.appendChild(deleteButton);
            });
        } catch (error) {
            console.error('Error loading rooms:', error);
        }
    };

    createRoomForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const name = document.getElementById('name').value;
        const capacity = document.getElementById('capacity').value;
        try {
            await createRoom({ name, capacity });
            createRoomForm.reset();
            loadRooms();
        } catch (error) {
            console.error('Error creating room:', error);
        }
    });

    loadRooms();
});
