<?php

namespace App\Http\Controllers;

use App\Models\Room;
use Illuminate\Http\Request;

class RoomController extends Controller
{
    public function index()
    {
        return response()->json(Room::all(), 200);
    }

    public function store(Request $request)
    {
        $room = Room::create($request->all());
        return response()->json($room, 201);
    }

    public function show($id)
    {
        $room = Room::find($id);
        if (is_null($room)) {
            return response()->json(['message' => 'Room not found'], 404);
        }
        return response()->json($room, 200);
    }

    public function update(Request $request, $id)
    {
        $room = Room::find($id);
        if (is_null($room)) {
            return response()->json(['message' => 'Room not found'], 404);
        }
        $room->update($request->all());
        return response()->json($room, 200);
    }

    public function destroy($id)
    {
        $room = Room::find($id);
        if (is_null($room)) {
            return response()->json(['message' => 'Room not found'], 404);
        }
        $room->delete();
        return response()->json(null, 204);
    }
}
