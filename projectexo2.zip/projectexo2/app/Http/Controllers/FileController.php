<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Response;

class FileController extends Controller
{
    public function upload(Request $request)
    {
        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $path = $file->store('public/files');
            return response()->json(['path' => $path], 201);
        }

        return response()->json(['message' => 'No file uploaded'], 400);
    }

    public function listFiles()
    {
        $files = Storage::files('public/files');
        $files = array_map(function($file) {
            return Storage::url($file);
        }, $files);
        return response()->json($files, 200);
    }
}
