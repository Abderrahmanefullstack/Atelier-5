const apiUrl = 'http://127.0.0.1:8000';

const uploadFile = async (file) => {
    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch(`${apiUrl}/upload`, {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            throw new Error('Failed to upload file');
        }

        return await response.json();
    } catch (error) {
        console.error(error);
        throw error;
    }
};

const fetchFiles = async () => {
    try {
        const response = await fetch(`${apiUrl}/files`);
        if (!response.ok) {
            throw new Error('Failed to fetch files');
        }
        return await response.json();
    } catch (error) {
        console.error(error);
        throw error;
    }
};
