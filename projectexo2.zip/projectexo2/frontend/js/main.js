document.addEventListener('DOMContentLoaded', () => {
    const uploadForm = document.getElementById('uploadForm');
    const fileInput = document.getElementById('fileInput');
    const fileList = document.getElementById('fileList');

    const loadFiles = async () => {
        try {
            const files = await fetchFiles();
            fileList.innerHTML = '';
            files.forEach(file => {
                const listItem = document.createElement('li');
                const link = document.createElement('a');
                link.href = file;
                link.textContent = file;
                listItem.appendChild(link);
                fileList.appendChild(listItem);
            });
        } catch (error) {
            console.error('Error loading files:', error);
        }
    };

    uploadForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const file = fileInput.files[0];
        if (file) {
            try {
                await uploadFile(file);
                fileInput.value = '';
                loadFiles();
            } catch (error) {
                console.error('Error uploading file:', error);
            }
        }
    });

    loadFiles();
});
